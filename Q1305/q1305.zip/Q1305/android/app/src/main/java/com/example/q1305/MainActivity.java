package com.example.q1305;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
